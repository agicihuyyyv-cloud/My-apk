plugins { id("com.android.application") }

android {
    namespace = "id.duitku.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "id.duitku.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
