# Duitku (Android)

App catatan keuangan harian dengan login username + password. Jalan full offline, data kesimpen di HP.

## Fitur
- Login & daftar pakai username + password (di-hash SHA-256 + salt, nggak pernah disimpen polos)
- Data terpisah per akun
- Catat pengeluaran & pemasukan, pilih tanggal, edit & hapus
- Budget per bulan, pindah bulan, cari catatan
- Statistik: per hari, per kategori, rata-rata, aman dipakai per hari, banding bulan lalu
- Akun: ganti password, budget default, hapus catatan, logout
- Panel Dev (khusus admin): lihat semua akun, bikin akun, reset password, jadikan/cabut admin, hapus akun

## Akun developer bawaan
Username: `agi_dev` (password dikasih terpisah). Ganti passwordnya di tab Akun setelah login pertama.

## Cara 1: Android Studio (paling gampang)
1. Extract zip ini.
2. Buka Android Studio > **Open** > pilih folder `DuitkuAndroid`.
3. Tunggu Gradle sync selesai (butuh internet, sekali aja).
4. Menu **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Klik **locate**, file `app-debug.apk` siap dikirim ke HP dan diinstall.

## Cara 2: Tanpa install apa-apa (GitHub)
1. Bikin repo baru di GitHub, upload semua isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions**, tunggu workflow "Build APK" hijau (sekitar 3-5 menit).
3. Klik run-nya, download **Duitku-apk** di bagian Artifacts, extract, install `app-debug.apk`.

Pas install, HP mungkin minta izin "Install dari sumber tidak dikenal": izinkan aja.

## Ubah tampilan
App yang dipakai ada di `app/src/main/assets/index.html` (hasil build). Source React-nya ada di folder `src-web/`.
