import { useState } from "react";
import { motion } from "motion/react";
import { Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Field, FieldGroup, FieldLabel, FieldError } from "@/components/ui/field";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { login, register } from "./store";

export function Login({ onAuth }) {
  const [mode, setMode] = useState("masuk");
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [p2, setP2] = useState("");
  const [show, setShow] = useState(false);
  const [err, setErr] = useState("");

  const submit = () => {
    setErr("");
    if (!u.trim() || !p) return setErr("Isi username dan password dulu.");
    if (mode === "daftar" && p !== p2) return setErr("Konfirmasi password nggak sama.");
    const r = mode === "masuk" ? login(u, p) : register(u, p);
    if (r.error) return setErr(r.error);
    onAuth(r.user);
  };
  const enter = (e) => e.key === "Enter" && submit();

  return (
    <main className="@container flex min-h-screen flex-col bg-background text-foreground">
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col px-4 pb-8 pt-12">
        <motion.div
          initial={{ rotate: -4, y: 20, opacity: 0 }}
          animate={{ rotate: -2, y: 0, opacity: 1 }}
          transition={{ type: "spring", stiffness: 120, damping: 16 }}
          className="note-sheet relative overflow-hidden rounded-lg px-6 py-8 text-paper"
          style={{ "--ink": "var(--color-note-makan)" }}
        >
          <span className="font-display text-sm font-bold uppercase tracking-[0.3em] text-paper/80">Catatan duit harian</span>
          <h1 className="font-display text-7xl font-bold uppercase leading-none tracking-wider">Duitku</h1>
          <div className="thread pointer-events-none absolute inset-y-0 w-2" />
        </motion.div>

        <Tabs value={mode} onValueChange={(v) => { setMode(v); setErr(""); }} className="mt-8">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="masuk">Masuk</TabsTrigger>
            <TabsTrigger value="daftar">Daftar</TabsTrigger>
          </TabsList>
        </Tabs>

        <FieldGroup className="mt-6">
          <Field>
            <FieldLabel htmlFor="u">Username</FieldLabel>
            <Input id="u" autoCapitalize="none" autoComplete="username" value={u} onChange={(e) => setU(e.target.value)} onKeyDown={enter} className="h-12 bg-paper" placeholder="misal: budi_santoso" />
          </Field>
          <Field>
            <FieldLabel htmlFor="p">Password</FieldLabel>
            <div className="relative">
              <Input id="p" type={show ? "text" : "password"} autoComplete={mode === "masuk" ? "current-password" : "new-password"} value={p} onChange={(e) => setP(e.target.value)} onKeyDown={enter} className="h-12 bg-paper pr-12" />
              <button type="button" aria-label={show ? "Sembunyikan password" : "Lihat password"} onClick={() => setShow((s) => !s)} className="absolute inset-y-0 right-0 flex w-12 items-center justify-center text-muted-foreground">
                {show ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
              </button>
            </div>
          </Field>
          {mode === "daftar" && (
            <Field>
              <FieldLabel htmlFor="p2">Ulangi password</FieldLabel>
              <Input id="p2" type={show ? "text" : "password"} autoComplete="new-password" value={p2} onChange={(e) => setP2(e.target.value)} onKeyDown={enter} className="h-12 bg-paper" />
            </Field>
          )}
          {err && <FieldError>{err}</FieldError>}
        </FieldGroup>

        <Button type="button" size="lg" onClick={submit} className="mt-8 h-14 w-full rounded-full font-display text-xl font-semibold uppercase tracking-widest">
          {mode === "masuk" ? "Masuk" : "Bikin akun"}
        </Button>
        <p className="mt-auto pt-8 text-center text-sm text-muted-foreground">Semua data tersimpan di HP ini aja.</p>
      </div>
    </main>
  );
}
