import { useState } from "react";
import { LogOut, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Field, FieldGroup, FieldLabel, FieldError } from "@/components/ui/field";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { changePassword } from "./store";
import { rp } from "./data";

export function Account({ user, data, onDefaultBudget, onWipe, onLogout }) {
  const [o, setO] = useState(""); const [n, setN] = useState(""); const [n2, setN2] = useState(""); const [err, setErr] = useState("");
  const [b, setB] = useState(String(data.defaultBudget));
  const bNum = parseInt(b.replace(/\D/g, ""), 10) || 0;

  const savePw = () => {
    setErr("");
    if (n !== n2) return setErr("Konfirmasi password baru nggak sama.");
    const r = changePassword(user.username, o, n);
    if (r.error) return setErr(r.error);
    setO(""); setN(""); setN2(""); toast.success("Password diganti");
  };

  return (
    <div className="mt-6 flex flex-col gap-8">
      <section className="note-sheet relative overflow-hidden rounded-lg px-4 py-5 text-paper" style={{ "--ink": user.role === "admin" ? "var(--color-note-jajan)" : "var(--color-note-transport)" }}>
        <span className="font-display text-sm font-bold uppercase tracking-[0.25em] text-paper/80">{user.role === "admin" ? "Akun developer" : "Akun"}</span>
        <p className="font-display text-5xl font-bold leading-none">@{user.username}</p>
        <p className="mt-2 text-sm text-paper/80">Gabung {new Date(user.createdAt).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })} · {data.items.length} catatan</p>
        {user.role === "admin" && <Badge className="absolute right-4 top-4 bg-paper text-foreground"><ShieldCheck /> Admin</Badge>}
      </section>

      <section>
        <h2 className="mb-3 font-display text-lg font-semibold uppercase tracking-wider text-muted-foreground">Budget default</h2>
        <div className="flex gap-2">
          <Input inputMode="numeric" aria-label="Budget default per bulan" value={"Rp" + bNum.toLocaleString("id-ID")} onChange={(e) => setB(e.target.value)} className="h-11 flex-1 bg-paper" />
          <Button type="button" variant="outline" className="h-11" disabled={bNum <= 0} onClick={() => { onDefaultBudget(bNum); toast.success("Budget default " + rp(bNum)); }}>Simpan</Button>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">Dipakai buat bulan yang belum punya budget sendiri.</p>
      </section>

      <section>
        <h2 className="mb-3 font-display text-lg font-semibold uppercase tracking-wider text-muted-foreground">Ganti password</h2>
        <FieldGroup>
          <Field><FieldLabel htmlFor="po">Password lama</FieldLabel><Input id="po" type="password" value={o} onChange={(e) => setO(e.target.value)} className="h-11 bg-paper" /></Field>
          <Field><FieldLabel htmlFor="pn">Password baru</FieldLabel><Input id="pn" type="password" value={n} onChange={(e) => setN(e.target.value)} className="h-11 bg-paper" /></Field>
          <Field><FieldLabel htmlFor="pn2">Ulangi password baru</FieldLabel><Input id="pn2" type="password" value={n2} onChange={(e) => setN2(e.target.value)} onKeyDown={(e) => e.key === "Enter" && savePw()} className="h-11 bg-paper" /></Field>
          {err && <FieldError>{err}</FieldError>}
        </FieldGroup>
        <Button type="button" className="mt-4 h-11 w-full" disabled={!o || !n} onClick={savePw}>Ganti password</Button>
      </section>

      <section className="flex flex-col gap-2">
        <AlertDialog>
          <AlertDialogTrigger asChild><Button type="button" variant="outline" className="h-11 text-primary">Hapus semua catatan saya</Button></AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Hapus semua catatan?</AlertDialogTitle>
              <AlertDialogDescription>{data.items.length} catatan bakal hilang permanen. Akun tetap ada.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Batal</AlertDialogCancel>
              <AlertDialogAction onClick={() => { onWipe(); toast("Catatan dihapus"); }}>Hapus</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
        <Button type="button" variant="ghost" className="h-11" onClick={onLogout}><LogOut /> Keluar dari akun</Button>
      </section>
    </div>
  );
}
