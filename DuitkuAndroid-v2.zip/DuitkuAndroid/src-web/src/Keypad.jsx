import { Delete } from "lucide-react";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "000", "0", "del"];

export function Keypad({ onKey }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {KEYS.map((k) => (
        <button
          key={k}
          type="button"
          aria-label={k === "del" ? "Hapus angka" : k}
          onClick={() => onKey(k)}
          className="flex h-14 items-center justify-center rounded-lg bg-paper font-display text-2xl font-semibold text-foreground shadow-[0_1px_0_oklch(0.24_0.04_275/0.12)] transition active:scale-95 active:bg-neutral-2"
        >
          {k === "del" ? <Delete className="size-6" /> : k}
        </button>
      ))}
    </div>
  );
}
