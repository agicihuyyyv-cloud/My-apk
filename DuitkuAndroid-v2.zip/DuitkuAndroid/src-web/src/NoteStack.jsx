import { motion } from "motion/react";
import { CATS } from "./data";

// Signature: the month's budget as a strip of rupiah notes; unspent stays as blank paper.
export function NoteStack({ totals, budget }) {
  const spent = CATS.reduce((a, c) => a + (totals[c.id] || 0), 0);
  const base = Math.max(budget, spent) || 1;
  return (
    <div className="relative h-24 w-full overflow-hidden rounded-lg bg-paper shadow-[inset_0_0_0_1px_oklch(0.24_0.04_275/0.12)]">
      <div className="flex h-full">
        {CATS.filter((c) => totals[c.id] > 0).map((c) => (
          <motion.div
            key={c.id}
            layout
            initial={{ width: 0 }}
            animate={{ width: `${(totals[c.id] / base) * 100}%` }}
            transition={{ type: "spring", stiffness: 140, damping: 22 }}
            className="note relative h-full shrink-0 overflow-hidden"
            style={{ "--ink": c.color }}
            title={c.label}
          >
            <span className="absolute left-2 top-1 font-display text-sm font-bold tracking-wide text-paper/90">
              {totals[c.id] / base > 0.11 ? c.note : ""}
            </span>
          </motion.div>
        ))}
      </div>
      {spent === 0 && <span className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground">Belum ada pengeluaran</span>}
      <div className="thread pointer-events-none absolute inset-y-0 w-2" />
    </div>
  );
}
