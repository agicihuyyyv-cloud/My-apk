import { sha256 } from "./sha256";

const K_USERS = "duitku.users";
const K_SESSION = "duitku.session";
const get = (k, f) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : f; } catch { return f; } };
const set = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

// Built-in developer account (password is stored only as a salted hash)
const ADMIN = { username: "agi_dev", salt: "bdc613d4d39206da61e63e55", hash: "0507fc5b98e8e06068b6e4b44d82912d30421a69b6cf912702113d6724a82b79", role: "admin" };

const norm = (s) => s.trim().toLowerCase();
const salt = () => Array.from(crypto.getRandomValues(new Uint8Array(12))).map((b) => b.toString(16).padStart(2, "0")).join("");
const check = (u, pw) => sha256(u.salt + pw) === u.hash;

export function getUsers() {
  let u = get(K_USERS, []);
  if (!u.some((x) => x.username === ADMIN.username)) {
    u = [{ ...ADMIN, createdAt: new Date().toISOString() }, ...u];
    set(K_USERS, u);
  }
  return u;
}
const saveUsers = (u) => set(K_USERS, u);
const pwError = (pw) => (pw.length < 6 ? "Password minimal 6 karakter." : null);

export function register(username, password) {
  const name = norm(username);
  if (!/^[a-z0-9_.]{3,20}$/.test(name)) return { error: "Username 3-20 karakter: huruf kecil, angka, titik, garis bawah." };
  const e = pwError(password); if (e) return { error: e };
  const users = getUsers();
  if (users.some((u) => u.username === name)) return { error: "Username itu udah dipakai." };
  const s = salt();
  const user = { username: name, salt: s, hash: sha256(s + password), role: "user", createdAt: new Date().toISOString() };
  saveUsers([...users, user]);
  set(K_SESSION, name);
  return { user };
}

export function login(username, password) {
  const u = getUsers().find((x) => x.username === norm(username));
  if (!u || !check(u, password)) return { error: "Username atau password salah." };
  set(K_SESSION, u.username);
  return { user: u };
}

export const currentUser = () => { const n = get(K_SESSION, null); return n ? getUsers().find((u) => u.username === n) || null : null; };
export const logout = () => { try { localStorage.removeItem(K_SESSION); } catch {} };

export function changePassword(username, oldPw, newPw) {
  const users = getUsers();
  const u = users.find((x) => x.username === username);
  if (!u || !check(u, oldPw)) return { error: "Password lama salah." };
  const e = pwError(newPw); if (e) return { error: e };
  const s = salt();
  saveUsers(users.map((x) => (x.username === username ? { ...x, salt: s, hash: sha256(s + newPw) } : x)));
  return { ok: true };
}

export function resetPassword(username, newPw) {
  const e = pwError(newPw); if (e) return { error: e };
  const s = salt();
  saveUsers(getUsers().map((x) => (x.username === username ? { ...x, salt: s, hash: sha256(s + newPw) } : x)));
  return { ok: true };
}

export function setRole(username, role) {
  if (username === ADMIN.username) return;
  saveUsers(getUsers().map((x) => (x.username === username ? { ...x, role } : x)));
}

export function deleteUser(username) {
  if (username === ADMIN.username) return;
  saveUsers(getUsers().filter((x) => x.username !== username));
  try { localStorage.removeItem("duitku.data." + username); } catch {}
}

export const isRootAdmin = (username) => username === ADMIN.username;
export const emptyData = () => ({ items: [], budgets: {}, defaultBudget: 3000000 });
export const loadData = (username) => ({ ...emptyData(), ...get("duitku.data." + username, {}) });
export const saveData = (username, d) => set("duitku.data." + username, d);
