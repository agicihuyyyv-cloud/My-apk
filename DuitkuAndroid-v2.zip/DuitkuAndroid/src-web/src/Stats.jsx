import { motion } from "motion/react";
import { CATS, rp } from "./data";

export function Stats({ monthItems, prevItems, month, budget }) {
  const out = monthItems.filter((i) => i.type !== "in");
  const spent = out.reduce((a, i) => a + i.amount, 0);
  const income = monthItems.filter((i) => i.type === "in").reduce((a, i) => a + i.amount, 0);
  const prevSpent = prevItems.filter((i) => i.type !== "in").reduce((a, i) => a + i.amount, 0);
  const now = new Date();
  const days = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const isCurrent = month.getFullYear() === now.getFullYear() && month.getMonth() === now.getMonth();
  const elapsed = isCurrent ? now.getDate() : days;
  const daily = Array.from({ length: days }, (_, d) => out.filter((i) => new Date(i.at).getDate() === d + 1).reduce((a, i) => a + i.amount, 0));
  const maxDay = Math.max(...daily, 1);
  const biggest = [...out].sort((a, b) => b.amount - a.amount)[0];
  const byCat = CATS.map((c) => ({ ...c, v: out.filter((i) => i.cat === c.id).reduce((a, i) => a + i.amount, 0) })).filter((c) => c.v > 0).sort((a, b) => b.v - a.v);
  const diff = prevSpent ? Math.round(((spent - prevSpent) / prevSpent) * 100) : null;
  const leftDays = isCurrent ? days - now.getDate() + 1 : 0;
  const safe = leftDays > 0 ? Math.max(budget - spent, 0) / leftDays : 0;

  return (
    <div className="mt-6 flex flex-col gap-8">
      <section>
        <p className="text-sm text-muted-foreground">Total keluar</p>
        <h1 className="font-display text-7xl font-bold leading-none tracking-tight tabular-nums">{rp(spent)}</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {diff === null ? "Belum ada data bulan lalu" : `${diff > 0 ? "naik" : "turun"} ${Math.abs(diff)}% dari bulan lalu`}
        </p>
      </section>

      <section className="grid grid-cols-2 gap-2">
        <Tile label="Rata-rata/hari" value={rp(spent / Math.max(elapsed, 1))} />
        {isCurrent ? <Tile label="Aman dipakai/hari" value={rp(safe)} /> : <Tile label="Transaksi" value={String(monthItems.length)} />}
        <Tile label="Pemasukan" value={"+" + rp(income)} accent />
        <Tile label="Masuk - keluar" value={rp(income - spent)} />
      </section>

      <section>
        <h2 className="mb-3 font-display text-lg font-semibold uppercase tracking-wider text-muted-foreground">Per hari</h2>
        <div className="flex h-36 items-end gap-[3px] rounded-lg bg-paper px-3 pb-3 pt-4">
          {daily.map((v, i) => {
            const today = isCurrent && i + 1 === now.getDate();
            return (
              <motion.div
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${Math.max((v / maxDay) * 100, v ? 4 : 1.5)}%` }}
                transition={{ delay: i * 0.012, type: "spring", stiffness: 160, damping: 22 }}
                className={`flex-1 rounded-sm ${v ? (today ? "bg-primary" : "bg-foreground/70") : "bg-neutral-3"}`}
                title={`${i + 1}: ${rp(v)}`}
              />
            );
          })}
        </div>
        <div className="mt-1 flex justify-between px-3 text-sm text-muted-foreground"><span>1</span><span>{Math.ceil(days / 2)}</span><span>{days}</span></div>
      </section>

      <section>
        <h2 className="mb-3 font-display text-lg font-semibold uppercase tracking-wider text-muted-foreground">Per kategori</h2>
        {byCat.length === 0 && <p className="text-muted-foreground">Belum ada pengeluaran bulan ini.</p>}
        <div className="flex flex-col gap-3">
          {byCat.map((c) => (
            <div key={c.id}>
              <div className="mb-1 flex items-baseline justify-between">
                <span>{c.label}</span>
                <span className="font-display text-lg font-semibold tabular-nums">{rp(c.v)} <span className="text-sm font-normal text-muted-foreground">{Math.round((c.v / spent) * 100)}%</span></span>
              </div>
              <div className="h-4 overflow-hidden rounded-sm bg-paper">
                <motion.div initial={{ width: 0 }} animate={{ width: `${(c.v / byCat[0].v) * 100}%` }} className="note h-full" style={{ "--ink": c.color }} />
              </div>
            </div>
          ))}
        </div>
      </section>

      {biggest && (
        <section className="rounded-lg bg-paper p-4">
          <p className="text-sm text-muted-foreground">Pengeluaran terbesar</p>
          <p className="font-display text-3xl font-semibold tabular-nums">{rp(biggest.amount)}</p>
          <p>{biggest.note || "Tanpa catatan"} · {new Date(biggest.at).toLocaleDateString("id-ID", { day: "numeric", month: "short" })}</p>
        </section>
      )}
    </div>
  );
}

function Tile({ label, value, accent }) {
  return (
    <div className="rounded-lg bg-paper px-3 py-3">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className={`font-display text-2xl font-semibold tabular-nums ${accent ? "text-income" : ""}`}>{value}</p>
    </div>
  );
}
