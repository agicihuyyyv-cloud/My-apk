export const CATS = [
  { id: "makan", label: "Makan", note: "100RB", color: "var(--color-note-makan)" },
  { id: "transport", label: "Transport", note: "50RB", color: "var(--color-note-transport)" },
  { id: "belanja", label: "Belanja", note: "20RB", color: "var(--color-note-belanja)" },
  { id: "jajan", label: "Jajan", note: "10RB", color: "var(--color-note-jajan)" },
  { id: "tagihan", label: "Tagihan", note: "5RB", color: "var(--color-note-tagihan)" },
  { id: "lainnya", label: "Lainnya", note: "2RB", color: "var(--color-note-lainnya)" },
];
export const IN_CATS = [
  { id: "gaji", label: "Gaji", color: "var(--color-income)" },
  { id: "bonus", label: "Bonus/THR", color: "var(--color-income)" },
  { id: "usaha", label: "Usaha", color: "var(--color-income)" },
  { id: "masuk_lain", label: "Lainnya", color: "var(--color-income)" },
];
export const catById = Object.fromEntries([...CATS, ...IN_CATS].map((c) => [c.id, c]));

export const rp = (n) => (n < 0 ? "-" : "") + "Rp" + Math.abs(Math.round(n)).toLocaleString("id-ID");
export const monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
export const inMonth = (iso, key) => monthKey(new Date(iso)) === key;
export const monthLabel = (d) => d.toLocaleDateString("id-ID", { month: "long", year: "numeric" });
export const toDateInput = (iso) => { const x = new Date(iso); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`; };
export const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

export const dayLabel = (iso) => {
  const t = new Date(); const x = new Date(iso);
  if (sameDay(t, x)) return "Hari ini";
  const y = new Date(t); y.setDate(t.getDate() - 1);
  if (sameDay(y, x)) return "Kemarin";
  return x.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "short" });
};
