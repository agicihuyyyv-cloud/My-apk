/*
 Duitku (Android build): offline expense tracker with local username/password accounts.
 Design: rupiah banknote inks on security-paper mint, Khand + Hind, budget as a strip of notes
 with a gliding gold security thread. Tabs: Beranda, Statistik, Akun, Dev (admin only).
*/
import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Home as HomeIcon, BarChart3, User, Terminal, Plus } from "lucide-react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import { monthKey, monthLabel, inMonth } from "./data";
import { currentUser, loadData, saveData, logout, emptyData, getUsers } from "./store";
import { Login } from "./Login";
import { Home } from "./Home";
import { Stats } from "./Stats";
import { Account } from "./Account";
import { Admin } from "./Admin";
import { EntryDrawer } from "./EntryDrawer";
import "./notes.css";

export default function App() {
  const [user, setUser] = useState(() => currentUser());
  return (
    <>
      {user ? <Main key={user.username} user={user} onLogout={() => { logout(); setUser(null); }} onUserChange={() => setUser(currentUser())} /> : <Login onAuth={setUser} />}
      <Toaster position="top-center" />
    </>
  );
}

function Main({ user, onLogout, onUserChange }) {
  const [data, setData] = useState(() => loadData(user.username));
  const [tab, setTab] = useState("home");
  const [month, setMonth] = useState(() => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), 1); });
  const [drawer, setDrawer] = useState({ open: false, item: null });

  useEffect(() => saveData(user.username, data), [user.username, data]);

  const key = monthKey(month);
  const prev = new Date(month.getFullYear(), month.getMonth() - 1, 1);
  const monthItems = useMemo(() => data.items.filter((i) => inMonth(i.at, key)), [data.items, key]);
  const prevItems = useMemo(() => data.items.filter((i) => inMonth(i.at, monthKey(prev))), [data.items, key]);
  const budget = data.budgets[key] ?? data.defaultBudget;
  const now = new Date();
  const isCurrent = month.getFullYear() === now.getFullYear() && month.getMonth() === now.getMonth();
  const isAdmin = user.role === "admin";

  const saveEntry = (e) => {
    setData((d) => {
      const exists = e.id && d.items.some((i) => i.id === e.id);
      const items = exists ? d.items.map((i) => (i.id === e.id ? e : i)) : [{ ...e, id: crypto.randomUUID?.() || String(Date.now()) }, ...d.items];
      return { ...d, items };
    });
    const m = new Date(e.at);
    if (monthKey(m) !== key) setMonth(new Date(m.getFullYear(), m.getMonth(), 1));
    toast.success(drawer.item ? "Catatan diubah" : "Tersimpan");
    setDrawer({ open: false, item: null });
  };
  const deleteEntry = (id) => {
    setData((d) => ({ ...d, items: d.items.filter((i) => i.id !== id) }));
    toast("Catatan dihapus");
    setDrawer({ open: false, item: null });
  };

  const tabs = [
    { id: "home", label: "Beranda", icon: HomeIcon },
    { id: "stats", label: "Statistik", icon: BarChart3 },
    { id: "add" },
    { id: "account", label: "Akun", icon: User },
    ...(isAdmin ? [{ id: "dev", label: "Dev", icon: Terminal }] : []),
  ];
  const showMonth = tab === "home" || tab === "stats";

  return (
    <main className="@container min-h-screen bg-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-md flex-col px-4 pb-32 pt-6">
        <header className="flex h-10 items-center justify-between">
          <span className="font-display text-xl font-bold uppercase tracking-[0.2em] text-primary">Duitku</span>
          {showMonth ? (
            <div className="flex items-center gap-1">
              <button type="button" aria-label="Bulan sebelumnya" onClick={() => setMonth(prev)} className="rounded-md p-2 text-muted-foreground active:bg-neutral-2"><ChevronLeft className="size-4" /></button>
              <span className="w-28 text-center text-sm">{monthLabel(month)}</span>
              <button type="button" aria-label="Bulan berikutnya" disabled={isCurrent} onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))} className="rounded-md p-2 text-muted-foreground active:bg-neutral-2 disabled:opacity-30"><ChevronRight className="size-4" /></button>
            </div>
          ) : (
            <span className="text-sm text-muted-foreground">@{user.username}</span>
          )}
        </header>

        {tab === "home" && (
          <Home
            items={data.items}
            monthItems={monthItems}
            budget={budget}
            onBudget={(v) => setData((d) => ({ ...d, budgets: { ...d.budgets, [key]: v } }))}
            onEdit={(item) => setDrawer({ open: true, item })}
          />
        )}
        {tab === "stats" && <Stats monthItems={monthItems} prevItems={prevItems} month={month} budget={budget} />}
        {tab === "account" && (
          <Account
            user={user}
            data={data}
            onDefaultBudget={(v) => setData((d) => ({ ...d, defaultBudget: v }))}
            onWipe={() => setData((d) => ({ ...emptyData(), defaultBudget: d.defaultBudget }))}
            onLogout={onLogout}
          />
        )}
        {tab === "dev" && isAdmin && <Admin me={user} onSelfChange={onUserChange} />}
      </div>

      <nav className="fixed inset-x-0 bottom-0 bg-background/95 pb-4 pt-2 shadow-[0_-1px_0_oklch(0.24_0.04_275/0.08)] backdrop-blur">
        <div className="mx-auto flex max-w-md items-end justify-around px-2">
          {tabs.map((t) =>
            t.id === "add" ? (
              <button key="add" type="button" aria-label="Catat transaksi" onClick={() => setDrawer({ open: true, item: null })} className="-mt-6 flex size-16 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition active:scale-95">
                <Plus className="size-7" />
              </button>
            ) : (
              <button key={t.id} type="button" onClick={() => setTab(t.id)} aria-current={tab === t.id ? "page" : undefined} className={`flex w-16 flex-col items-center gap-0.5 py-1 text-sm transition ${tab === t.id ? "text-primary" : "text-muted-foreground"}`}>
                <t.icon className="size-5" />
                {t.label}
              </button>
            )
          )}
        </div>
      </nav>

      <EntryDrawer open={drawer.open} initial={drawer.item} onOpenChange={(o) => setDrawer((s) => ({ ...s, open: o }))} onSave={saveEntry} onDelete={deleteEntry} />
    </main>
  );
}
