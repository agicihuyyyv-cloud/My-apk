import { useState } from "react";
import { KeyRound, Trash2, UserPlus, ShieldCheck, Shield } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { getUsers, loadData, resetPassword, deleteUser, register, setRole, isRootAdmin, currentUser } from "./store";
import { rp } from "./data";

export function Admin({ me, onSelfChange }) {
  const [tick, setTick] = useState(0);
  const refresh = () => setTick((t) => t + 1);
  const users = getUsers().map((u) => {
    const d = loadData(u.username);
    return { ...u, count: d.items.length, out: d.items.filter((i) => i.type !== "in").reduce((a, i) => a + i.amount, 0) };
  });
  const [resetFor, setResetFor] = useState(null);
  const [newPw, setNewPw] = useState("");
  const [delFor, setDelFor] = useState(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [cu, setCu] = useState(""); const [cp, setCp] = useState(""); const [cErr, setCErr] = useState("");

  const totalEntries = users.reduce((a, u) => a + u.count, 0);
  const totalOut = users.reduce((a, u) => a + u.out, 0);

  const doReset = () => {
    const r = resetPassword(resetFor, newPw);
    if (r.error) return toast.error(r.error);
    toast.success(`Password @${resetFor} direset`); setResetFor(null); setNewPw("");
  };
  const doCreate = () => {
    setCErr("");
    const session = currentUser();
    const r = register(cu, cp);
    if (r.error) return setCErr(r.error);
    // register logs the new user in; restore the admin session
    try { localStorage.setItem("duitku.session", JSON.stringify(session.username)); } catch {}
    toast.success(`Akun @${r.user.username} dibuat`); setCreateOpen(false); setCu(""); setCp(""); refresh();
  };

  return (
    <div className="mt-6 flex flex-col gap-8" data-tick={tick}>
      <section>
        <p className="text-sm text-muted-foreground">Panel developer</p>
        <h1 className="font-display text-7xl font-bold leading-none tracking-tight tabular-nums">{users.length} akun</h1>
        <p className="mt-2 text-sm text-muted-foreground">{totalEntries} catatan · {rp(totalOut)} tercatat keluar</p>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold uppercase tracking-wider text-muted-foreground">Pengguna</h2>
          <Button type="button" size="sm" variant="outline" onClick={() => setCreateOpen(true)}><UserPlus /> Akun baru</Button>
        </div>
        <ul className="flex flex-col gap-2">
          {users.map((u) => {
            const root = isRootAdmin(u.username);
            return (
              <li key={u.username} className="rounded-lg bg-paper px-4 py-3">
                <div className="flex items-center gap-2">
                  <p className="min-w-0 flex-1 truncate font-display text-xl font-semibold">@{u.username}</p>
                  {u.role === "admin" && <Badge variant="secondary"><ShieldCheck /> {root ? "Dev" : "Admin"}</Badge>}
                </div>
                <p className="text-sm text-muted-foreground">{u.count} catatan · {rp(u.out)} · sejak {new Date(u.createdAt).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" })}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Button type="button" size="sm" variant="outline" onClick={() => { setResetFor(u.username); setNewPw(""); }}><KeyRound /> Reset password</Button>
                  {!root && (
                    <Button type="button" size="sm" variant="outline" onClick={() => { setRole(u.username, u.role === "admin" ? "user" : "admin"); toast(u.role === "admin" ? `@${u.username} jadi user biasa` : `@${u.username} jadi admin`); refresh(); if (u.username === me.username) onSelfChange(); }}>
                      <Shield /> {u.role === "admin" ? "Cabut admin" : "Jadikan admin"}
                    </Button>
                  )}
                  {!root && u.username !== me.username && (
                    <Button type="button" size="sm" variant="ghost" className="text-primary" onClick={() => setDelFor(u.username)}><Trash2 /> Hapus</Button>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <Dialog open={!!resetFor} onOpenChange={(o) => !o && setResetFor(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reset password @{resetFor}</DialogTitle><DialogDescription>Kasih password baru ke orangnya langsung.</DialogDescription></DialogHeader>
          <Input autoFocus type="text" aria-label="Password baru" placeholder="Password baru (min. 6)" value={newPw} onChange={(e) => setNewPw(e.target.value)} onKeyDown={(e) => e.key === "Enter" && doReset()} className="h-11" />
          <DialogFooter><Button type="button" onClick={doReset}>Simpan password</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Akun baru</DialogTitle><DialogDescription>Bikinin akun buat orang lain di HP ini.</DialogDescription></DialogHeader>
          <Input aria-label="Username" placeholder="Username" autoCapitalize="none" value={cu} onChange={(e) => setCu(e.target.value)} className="h-11" />
          <Input aria-label="Password" placeholder="Password (min. 6)" value={cp} onChange={(e) => setCp(e.target.value)} onKeyDown={(e) => e.key === "Enter" && doCreate()} className="h-11" />
          {cErr && <p className="text-sm text-destructive">{cErr}</p>}
          <DialogFooter><Button type="button" onClick={doCreate}>Bikin akun</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!delFor} onOpenChange={(o) => !o && setDelFor(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Hapus @{delFor}?</AlertDialogTitle><AlertDialogDescription>Akun dan semua catatannya hilang permanen.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={() => { deleteUser(delFor); toast(`@${delFor} dihapus`); setDelFor(null); refresh(); }}>Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
