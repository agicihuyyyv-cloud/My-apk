import { useEffect, useState } from "react";
import { Trash2 } from "lucide-react";
import { Drawer, DrawerContent, DrawerTitle, DrawerDescription } from "@/components/ui/drawer";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { CATS, IN_CATS, catById, rp, toDateInput } from "./data";
import { Keypad } from "./Keypad";

export function EntryDrawer({ open, onOpenChange, initial, onSave, onDelete }) {
  const [type, setType] = useState("out");
  const [amt, setAmt] = useState("");
  const [cat, setCat] = useState("makan");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(toDateInput(new Date().toISOString()));

  useEffect(() => {
    if (!open) return;
    if (initial) {
      setType(initial.type || "out"); setAmt(String(initial.amount)); setCat(initial.cat);
      setNote(initial.note || ""); setDate(toDateInput(initial.at));
    } else {
      setType("out"); setAmt(""); setCat("makan"); setNote(""); setDate(toDateInput(new Date().toISOString()));
    }
  }, [open, initial]);

  const switchType = (t) => { if (!t) return; setType(t); setCat(t === "in" ? "gaji" : "makan"); };
  const press = (k) => {
    if (k === "del") return setAmt((a) => a.slice(0, -1));
    setAmt((a) => (a + k).replace(/^0+/, "").slice(0, 11));
  };
  const n = parseInt(amt || "0", 10);
  const c = catById[cat];
  const cats = type === "in" ? IN_CATS : CATS;

  const save = () => {
    if (n <= 0) return;
    const [y, m, d] = date.split("-").map(Number);
    const base = initial ? new Date(initial.at) : new Date();
    const at = new Date(y, m - 1, d, base.getHours(), base.getMinutes(), base.getSeconds()).toISOString();
    onSave({ ...(initial || {}), type, amount: n, cat, note: note.trim(), at });
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="mx-auto max-w-md bg-background">
        <DrawerTitle className="sr-only">{initial ? "Ubah catatan" : "Catat transaksi"}</DrawerTitle>
        <DrawerDescription className="sr-only">Pilih jenis, nominal, kategori dan tanggal, lalu simpan.</DrawerDescription>
        <div className="max-h-[85vh] overflow-y-auto px-4 pb-6 pt-2">
          <div className="flex items-center gap-2">
            <ToggleGroup type="single" value={type} onValueChange={switchType} variant="outline" className="flex-1">
              <ToggleGroupItem value="out" className="flex-1">Keluar</ToggleGroupItem>
              <ToggleGroupItem value="in" className="flex-1">Masuk</ToggleGroupItem>
            </ToggleGroup>
            <Input type="date" aria-label="Tanggal" value={date} max={toDateInput(new Date().toISOString())} onChange={(e) => e.target.value && setDate(e.target.value)} className="h-9 w-40 bg-paper" />
          </div>
          <div className="note-sheet relative mt-3 overflow-hidden rounded-lg px-4 py-4 text-paper" style={{ "--ink": c.color }}>
            <span className="font-display text-sm font-bold uppercase tracking-[0.25em] text-paper/80">{type === "in" ? "Masuk · " : ""}{c.label}</span>
            <p className="font-display text-6xl font-bold leading-none tabular-nums">{type === "in" ? "+" : ""}{rp(n)}</p>
          </div>
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {cats.map((x) => (
              <button
                key={x.id}
                type="button"
                onClick={() => setCat(x.id)}
                aria-pressed={cat === x.id}
                className="shrink-0 rounded-full px-3 py-1.5 text-sm transition"
                style={cat === x.id ? { background: x.color, color: "var(--color-paper)" } : { boxShadow: `inset 0 0 0 1.5px ${x.color}`, color: x.color }}
              >
                {x.label}
              </button>
            ))}
          </div>
          <Input value={note} onChange={(e) => setNote(e.target.value)} onKeyDown={(e) => e.key === "Enter" && save()} placeholder={type === "in" ? "Dari mana? (opsional)" : "Buat apa? (opsional)"} className="mt-3 h-11 bg-paper" aria-label="Catatan" />
          <div className="mt-3"><Keypad onKey={press} /></div>
          <div className="mt-3 flex gap-2">
            {initial && (
              <Button type="button" size="lg" variant="outline" aria-label="Hapus catatan" onClick={() => onDelete(initial.id)} className="h-14 w-14 rounded-full text-primary">
                <Trash2 className="size-5" />
              </Button>
            )}
            <Button type="button" size="lg" disabled={n <= 0} onClick={save} className="h-14 flex-1 rounded-full font-display text-xl font-semibold uppercase tracking-widest">
              {initial ? "Simpan perubahan" : "Simpan"}
            </Button>
          </div>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
