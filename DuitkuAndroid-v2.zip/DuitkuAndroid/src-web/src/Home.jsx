import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Pencil, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { CATS, catById, rp, dayLabel } from "./data";
import { NoteStack } from "./NoteStack";

export function Home({ items, budget, onBudget, onEdit, monthItems }) {
  const [editBudget, setEditBudget] = useState(false);
  const [filter, setFilter] = useState("");
  const [q, setQ] = useState("");

  const totals = useMemo(() => {
    const t = {};
    monthItems.filter((i) => i.type !== "in").forEach((i) => (t[i.cat] = (t[i.cat] || 0) + i.amount));
    return t;
  }, [monthItems]);
  const spent = monthItems.filter((i) => i.type !== "in").reduce((a, i) => a + i.amount, 0);
  const income = monthItems.filter((i) => i.type === "in").reduce((a, i) => a + i.amount, 0);
  const left = budget - spent;

  const groups = useMemo(() => {
    const s = q.trim().toLowerCase();
    const list = monthItems
      .filter((i) => (!filter || (filter === "in" ? i.type === "in" : i.cat === filter)))
      .filter((i) => !s || (i.note || "").toLowerCase().includes(s) || catById[i.cat].label.toLowerCase().includes(s))
      .sort((a, b) => b.at.localeCompare(a.at));
    const g = [];
    list.forEach((i) => {
      const k = dayLabel(i.at);
      const last = g[g.length - 1];
      if (last && last.k === k) last.rows.push(i); else g.push({ k, rows: [i] });
    });
    return g;
  }, [monthItems, filter, q]);

  return (
    <>
      <section className="mt-6">
        <p className="text-sm text-muted-foreground">Sisa budget</p>
        <motion.h1 key={left} initial={{ y: 8, opacity: 0.4 }} animate={{ y: 0, opacity: 1 }} className={`font-display text-7xl font-bold leading-none tracking-tight tabular-nums ${left < 0 ? "text-primary" : ""}`}>
          {rp(left)}
        </motion.h1>
        <div className="mt-2 text-sm text-muted-foreground">
          {editBudget ? (
            <BudgetEdit value={budget} onDone={(v) => { if (v > 0) onBudget(v); setEditBudget(false); }} />
          ) : (
            <button type="button" onClick={() => setEditBudget(true)} className="flex items-center gap-1 underline-offset-4 hover:underline">
              keluar {rp(spent)} dari {rp(budget)} <Pencil className="size-3.5" />
            </button>
          )}
        </div>
      </section>

      <section className="mt-6">
        <NoteStack totals={totals} budget={budget} />
        <ToggleGroup type="single" value={filter} onValueChange={setFilter} className="mt-4 grid w-full grid-cols-3 gap-2">
          {CATS.map((c) => (
            <ToggleGroupItem key={c.id} value={c.id} className="h-auto flex-col items-start rounded-lg border-0 bg-paper px-3 py-2 text-left data-[state=on]:bg-[color-mix(in_oklch,var(--ink)_14%,var(--color-paper))] data-[state=on]:shadow-[inset_0_0_0_1.5px_var(--ink)]" style={{ "--ink": c.color }}>
              <span className="flex items-center gap-1.5 text-sm"><span className="size-2.5 rounded-full" style={{ background: c.color }} />{c.label}</span>
              <span className="font-display text-lg font-semibold tabular-nums">{rp(totals[c.id] || 0)}</span>
            </ToggleGroupItem>
          ))}
          <ToggleGroupItem value="in" className="col-span-3 h-auto justify-between rounded-lg border-0 bg-paper px-3 py-2 data-[state=on]:bg-[color-mix(in_oklch,var(--ink)_14%,var(--color-paper))] data-[state=on]:shadow-[inset_0_0_0_1.5px_var(--ink)]" style={{ "--ink": "var(--color-income)" }}>
            <span className="flex items-center gap-1.5 text-sm"><span className="size-2.5 rounded-full bg-income" />Pemasukan bulan ini</span>
            <span className="font-display text-lg font-semibold tabular-nums text-income">+{rp(income)}</span>
          </ToggleGroupItem>
        </ToggleGroup>
      </section>

      <section className="mt-8">
        <div className="relative mb-4">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari catatan" aria-label="Cari catatan" className="h-11 bg-paper pl-9" />
        </div>
        {groups.length === 0 && <p className="py-12 text-center text-muted-foreground">{items.length ? "Nggak ada yang cocok." : "Belum ada catatan. Tap + buat mulai."}</p>}
        {groups.map((g) => {
          const out = g.rows.filter((r) => r.type !== "in").reduce((a, r) => a + r.amount, 0);
          return (
            <div key={g.k} className="mb-6">
              <div className="mb-2 flex items-baseline justify-between">
                <h2 className="font-display text-lg font-semibold uppercase tracking-wider text-muted-foreground">{g.k}</h2>
                {out > 0 && <span className="text-sm tabular-nums text-muted-foreground">-{rp(out)}</span>}
              </div>
              <ul className="overflow-hidden rounded-lg bg-paper">
                <AnimatePresence initial={false}>
                  {g.rows.map((r) => {
                    const c = catById[r.cat];
                    const isIn = r.type === "in";
                    return (
                      <motion.li key={r.id} layout initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="[&+&]:shadow-[inset_0_1px_0_var(--color-background)]">
                        <button type="button" onClick={() => onEdit(r)} className="relative flex w-full items-center gap-3 py-3 pl-4 pr-4 text-left active:bg-neutral-2">
                          <span className="absolute inset-y-2 left-0 w-1 rounded-r" style={{ background: c.color }} />
                          <div className="min-w-0 flex-1">
                            <p className="truncate">{r.note || c.label}</p>
                            <p className="text-sm text-muted-foreground">{isIn ? "Masuk · " : ""}{c.label}</p>
                          </div>
                          <span className={`font-display text-xl font-semibold tabular-nums ${isIn ? "text-income" : ""}`}>{isIn ? "+" : "-"}{rp(r.amount)}</span>
                        </button>
                      </motion.li>
                    );
                  })}
                </AnimatePresence>
              </ul>
            </div>
          );
        })}
      </section>
    </>
  );
}

function BudgetEdit({ value, onDone }) {
  const [v, setV] = useState(String(value));
  const num = parseInt(v.replace(/\D/g, ""), 10) || 0;
  return (
    <span className="flex items-center gap-2">
      budget Rp
      <Input autoFocus inputMode="numeric" value={num.toLocaleString("id-ID")} onChange={(e) => setV(e.target.value)} onKeyDown={(e) => e.key === "Enter" && onDone(num)} onBlur={() => onDone(num)} className="h-8 w-36 bg-paper" aria-label="Budget bulan ini" />
    </span>
  );
}
